#import "DaoPrKit.h"
#import "___FILEBASENAMEASIDENTIFIER___.h"

@interface ___FILEBASENAMEASIDENTIFIER___View
:SoulTableItemView
<___FILEBASENAMEASIDENTIFIER___Nucleus>

@end
