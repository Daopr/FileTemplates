#import "DaoPrKit.h"
#import "___FILEBASENAMEASIDENTIFIER___.h"

@interface ___FILEBASENAMEASIDENTIFIER___View
:SoulTableView
<___FILEBASENAMEASIDENTIFIER___Nucleus>

@end
