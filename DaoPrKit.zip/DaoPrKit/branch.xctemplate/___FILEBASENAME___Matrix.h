#import "DaoPrKit.h"

@protocol ___FILEBASENAMEASIDENTIFIER___Nucleus
<SoulNucleus>
@optional


@end @interface ___FILEBASENAMEASIDENTIFIER___
:NotMan
<___FILEBASENAMEASIDENTIFIER___Nucleus>
@end

