#import "___FILEBASENAMEASIDENTIFIER___View.h"

@interface ___FILEBASENAMEASIDENTIFIER___View ()

@end

@implementation ___FILEBASENAMEASIDENTIFIER___View
- (void)initScene
{

}
@end
