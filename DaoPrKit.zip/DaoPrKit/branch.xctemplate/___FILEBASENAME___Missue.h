#import "DaoPrKit.h"
#import "___FILEBASENAMEASIDENTIFIER___.h"

@interface ___FILEBASENAMEASIDENTIFIER___Missue
:SoulMissue
<___FILEBASENAMEASIDENTIFIER___Nucleus>

@end
