#import "___FILEBASENAMEASIDENTIFIER___Crown.h"

@interface ___FILEBASENAMEASIDENTIFIER___Crown ()

@end

@implementation ___FILEBASENAMEASIDENTIFIER___Crown
-(void)initScene {
//    self.xylem.title = @"";
//    self.thread.title = @"";
}
@end
