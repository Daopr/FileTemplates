#import "___FILEBASENAMEASIDENTIFIER___Missue.h"

@interface ___FILEBASENAMEASIDENTIFIER___Missue ()

@end

@implementation ___FILEBASENAMEASIDENTIFIER___Missue
- (void)initScene
{

}
@end
