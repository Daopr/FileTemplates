#import "DaoPrKit.h"
#import "___FILEBASENAMEASIDENTIFIER___.h"

@interface ___FILEBASENAMEASIDENTIFIER___Crown
:SoulCrown
<___FILEBASENAMEASIDENTIFIER___Nucleus>

@end
